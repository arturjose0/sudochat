-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 06-Abr-2025 às 23:20
-- Versão do servidor: 11.4.4-MariaDB-cll-lve
-- versão do PHP: 8.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de dados: `chanceap_teste_laravel`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `actividades`
--

CREATE TABLE `actividades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `servicoe_posto__posto_saude_id` bigint(20) UNSIGNED DEFAULT NULL,
  `horario` datetime NOT NULL COMMENT 'data e hora da realizacao',
  `tema` varchar(155) NOT NULL,
  `palestrante_id` bigint(20) UNSIGNED DEFAULT NULL,
  `publico_alvo` varchar(255) NOT NULL,
  `participantes` int(11) NOT NULL COMMENT 'numero de participantes',
  `descricao` text DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `tipo_de_local` enum('escola','centro_de_saude') NOT NULL DEFAULT 'escola',
  `actividadeable_type` varchar(255) DEFAULT NULL,
  `actividadeable_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `actividades`
--

INSERT INTO `actividades` (`id`, `servicoe_posto__posto_saude_id`, `horario`, `tema`, `palestrante_id`, `publico_alvo`, `participantes`, `descricao`, `estado`, `tipo_de_local`, `actividadeable_type`, `actividadeable_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, '2017-08-30 18:02:53', 'Non voluptatem mollitia quis quia iste harum omnis.', 1, 'Sunt sunt ipsum minus quidem.', 33, 'Numquam voluptatem est quae quia omnis. Laborum nulla architecto debitis qui. Eum nemo deleniti voluptatibus numquam enim. Aut voluptates aliquam voluptate fugit mollitia sed.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(2, NULL, '2001-07-08 15:53:14', 'Earum consequuntur molestiae iure aut labore voluptas deserunt culpa.', 1, 'Odit provident id qui.', 228, 'Repellat corporis rerum qui non qui a a. Doloremque dolores incidunt quia aut omnis sint nobis aut. Voluptatem et voluptas adipisci at est saepe.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(3, NULL, '1987-05-11 15:24:59', 'Ex nihil ex eos officia dolore dicta.', 1, 'Perferendis facilis deleniti est quaerat cupiditate.', 371, 'Cumque error voluptatem officiis non voluptas doloremque animi. In quam quam soluta occaecati et non numquam minima. Voluptas facere facilis eligendi dolores delectus laboriosam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(4, NULL, '2009-04-06 07:07:48', 'Sint fuga ipsa tempora nostrum ducimus odio est.', 1, 'Blanditiis unde explicabo dolores voluptates nihil tempora.', 454, 'Architecto fugit eligendi architecto quae. Mollitia eius veritatis cum ex repudiandae temporibus exercitationem. Magni enim id id quia sint sit.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(5, NULL, '2013-12-27 18:20:59', 'Veniam harum iste sunt qui occaecati.', 1, 'Architecto facere ducimus eos neque.', 224, 'Eum ad numquam pariatur. Dolorem beatae nihil eos laboriosam et voluptas blanditiis. Consectetur ducimus porro quibusdam. Molestias perspiciatis vel veritatis eveniet corporis similique et.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(6, NULL, '2008-09-17 07:27:47', 'Sint laboriosam consequuntur eligendi temporibus est.', 1, 'Eaque aut dolor dolores.', 286, 'Sit alias qui voluptatem dolor assumenda unde eos eos. Saepe assumenda corrupti sed sapiente. Fuga animi odio accusamus. Nisi possimus alias aliquam molestiae ducimus magni.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(7, NULL, '2020-07-28 10:56:02', 'Animi enim excepturi sunt quos laboriosam rem.', 1, 'Eveniet unde praesentium nisi veritatis sed.', 448, 'Libero fugiat voluptates aut voluptatem. Sit itaque molestiae suscipit doloribus minima aut mollitia. Aut at id dolorum nam voluptatem. Non quo consequatur beatae non repellendus aliquam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(8, NULL, '1994-03-04 01:03:13', 'Quia odio nobis iusto nulla earum.', 1, 'Eligendi atque quia at ea eos repudiandae ipsum.', 369, 'Mollitia enim harum quis sed ut perspiciatis eaque. Officiis recusandae voluptates voluptas fugit. Sed nihil velit nam unde ratione. A atque explicabo ea qui quo voluptatem totam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(9, NULL, '1995-05-13 10:36:21', 'Error corrupti et ducimus voluptas nam possimus asperiores.', 1, 'Quo sed quis blanditiis est eius.', 297, 'Qui quia dolores porro vitae sit enim. Est ratione ut possimus hic deleniti aut nihil. Voluptatem quasi repellendus quo ipsam non iusto ea. Sit ipsa illum tenetur dolor repellat. Ipsam ut et tenetur explicabo saepe inventore quasi consequuntur.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(10, NULL, '2023-12-09 14:58:38', 'Est sit dolorem dignissimos in sed repellat fuga.', 1, 'Voluptate eius quam soluta omnis odio placeat dolor.', 438, 'Fuga assumenda est doloribus. Dolore iste similique non nihil. Ut nostrum pariatur et reprehenderit quos fugit. Architecto iusto corrupti dolore blanditiis sequi quis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(11, NULL, '1988-03-09 19:55:06', 'Qui iusto molestiae saepe qui aut animi velit.', 1, 'Ex beatae qui et et quas nihil.', 387, 'Architecto reiciendis non et asperiores rerum praesentium et. Et in architecto laboriosam blanditiis in. Dolorum consequatur qui eligendi. Id dolor voluptas maxime dolor eligendi.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(12, NULL, '1972-02-01 00:17:48', 'Aut numquam et dolore et.', 1, 'Facere est rerum aliquam voluptatum et consequatur.', 177, 'Quis tempore rerum distinctio est neque vitae ipsum aut. Alias deleniti quas eligendi voluptatem dolor.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(13, NULL, '2013-07-29 07:25:27', 'Sunt et assumenda veritatis dicta placeat labore fuga.', 1, 'Ut vel iusto soluta delectus deleniti cum.', 392, 'Explicabo debitis iure sapiente exercitationem. Hic nostrum hic pariatur autem ut aut ea. Nulla tempora officia et dolor quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(14, NULL, '1982-01-30 02:06:13', 'Est velit sequi commodi aliquam temporibus sed laborum optio.', 1, 'Animi sint aspernatur vero est enim sunt.', 163, 'Sint blanditiis quaerat non sint. Impedit exercitationem velit ratione. Laborum expedita ipsam quia temporibus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(15, NULL, '2004-11-24 12:12:58', 'Architecto omnis asperiores nulla.', 1, 'A minima dolorem quo explicabo nostrum vel blanditiis.', 150, 'Minima cupiditate et consequatur eveniet. Culpa sequi aut quaerat quis sit recusandae. Sed eligendi eos maiores occaecati nesciunt.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(16, NULL, '1981-03-25 10:37:32', 'Tempora ut nostrum eos nostrum et iusto sapiente.', 1, 'Placeat aut eaque facilis facere consectetur corrupti.', 85, 'Vel tempora quam optio. Provident iure tempora et sapiente facere omnis delectus. Quo omnis sed dicta esse quae. Non doloremque dolorum dolor mollitia harum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(17, NULL, '1975-11-11 04:22:09', 'Harum voluptatibus laboriosam illo.', 1, 'Totam aspernatur consequatur voluptatem rerum sunt ab sint.', 317, 'Explicabo labore est tenetur vitae quod ex veritatis rem. Odit mollitia dolorum ut. Rerum quo aut qui a deserunt culpa asperiores.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(18, NULL, '2015-07-10 12:05:23', 'Voluptates rerum nesciunt quod officia voluptatem rerum dolores.', 1, 'Voluptatem neque et aut corporis dolorem deleniti animi.', 189, 'Fuga cumque laborum sint et tempora ipsa. Qui tenetur sit vel possimus dolorem qui. Culpa dolores dolorum eveniet. Quibusdam tempore corrupti similique tenetur iusto.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(19, NULL, '2000-05-06 23:55:30', 'Facilis ad accusamus soluta et.', 1, 'Eos recusandae non minima non eveniet.', 417, 'Modi eos laudantium ad aliquam rem inventore. Maxime dolorem commodi eveniet nihil numquam accusantium. Fugiat cum aut similique vel.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(20, NULL, '2020-09-19 07:58:33', 'Reprehenderit et provident eligendi sed.', 1, 'Repudiandae esse harum cupiditate vero temporibus in.', 266, 'Dolorum magni aperiam voluptatem non dolor doloribus unde. Ea expedita aut odit quis nesciunt. Aspernatur et dolorum dolorum sit amet alias.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(21, NULL, '1989-08-04 18:24:56', 'Sunt voluptatem provident ex sapiente voluptates voluptate repudiandae minima.', 1, 'Nesciunt necessitatibus et occaecati dolores distinctio tempora.', 451, 'At sed itaque explicabo amet illo illum. Omnis unde ea velit similique ut sit. Dolores recusandae quo minus eius ullam est. Quas ut ea animi rem iure.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(22, NULL, '2012-02-16 19:06:00', 'Sit ullam quia atque sed qui mollitia distinctio.', 1, 'Molestiae qui et consectetur fugit.', 439, 'Unde possimus non amet doloremque facilis. Cupiditate cum rerum similique voluptas amet molestiae odit voluptas.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(23, NULL, '2010-11-04 02:50:44', 'Harum libero perspiciatis fugiat et quia.', 1, 'Ut assumenda ex voluptas nesciunt quia aspernatur.', 49, 'Et voluptas aut consectetur non debitis optio. Rerum minima id rem voluptas est quod optio. Error aliquid id cupiditate nisi culpa. Sunt inventore nam quia dolor. Repudiandae velit possimus incidunt ut.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(24, NULL, '1979-08-17 12:19:38', 'Consectetur aut laudantium impedit.', 1, 'Officia omnis facilis sequi nobis harum dolorem.', 354, 'Modi consequatur non molestiae est voluptatem unde. Autem aspernatur molestiae eum quia dignissimos in.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(25, NULL, '1987-07-13 16:10:27', 'Id temporibus corporis qui id consequatur recusandae.', 1, 'Pariatur molestiae voluptates autem velit.', 83, 'Necessitatibus corrupti natus delectus occaecati quo eum. Aut quia soluta quia non quo fuga aliquid culpa.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(26, NULL, '1986-01-23 19:41:31', 'Ut qui reprehenderit molestiae hic aut.', 1, 'Ullam rerum magnam facere ut saepe.', 294, 'Consequatur quia enim quas praesentium atque enim. Commodi sunt sunt ut impedit rem impedit eligendi.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(27, NULL, '1993-03-26 15:20:34', 'In eos aperiam quos ut culpa ad quos.', 1, 'Ab sit aut neque eum voluptas recusandae perferendis qui.', 276, 'Quas consequatur eius libero. A fuga qui voluptatibus occaecati. Quasi est odio eum sed quia rem omnis. Quod et dolor numquam delectus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(28, NULL, '1972-12-22 14:21:02', 'Reprehenderit iusto eveniet iure laudantium.', 1, 'Et est eum est quia non impedit eos.', 340, 'Enim fuga alias dignissimos dolorum architecto sit. Doloribus nihil cum ut accusantium sunt quod iure quia. Eum ea inventore maxime aut.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(29, NULL, '2007-12-26 16:36:57', 'Et architecto unde quam et atque hic.', 1, 'Occaecati porro molestiae id aut et vero.', 239, 'Error similique aut praesentium quia inventore aut. Similique iure non iusto iste. Aut et veniam a rerum suscipit et. Aliquam porro eaque omnis quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(30, NULL, '1984-10-07 19:53:30', 'Earum aut quod id distinctio autem.', 1, 'Quos ut quos velit officia molestiae et.', 446, 'Mollitia tempore quia blanditiis provident molestiae. Laboriosam fuga dolor optio est aut magni qui. Doloremque debitis voluptas cum odio dolorum quod. Quibusdam et accusantium sit et nostrum eius quam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:53', '2025-03-24 09:58:53', NULL),
(31, NULL, '1993-05-21 21:39:24', 'Laboriosam laborum perspiciatis autem aut.', 1, 'Omnis enim aperiam quisquam inventore.', 481, 'Consequatur dolor iste corrupti dolor et animi. Laborum eveniet laudantium et quidem exercitationem. Tenetur repellendus repellendus voluptatibus minima qui.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(32, NULL, '1981-10-18 00:22:09', 'Nulla et fuga eos repellendus eum voluptatem quo.', 1, 'Amet iusto error et qui aut dolore.', 97, 'Et nemo facilis consequuntur. Corporis ut suscipit ut ut vitae est nesciunt.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(33, NULL, '1986-10-30 23:42:47', 'Nostrum quis provident voluptatem ab cumque.', 1, 'Reiciendis omnis enim totam impedit.', 460, 'Mollitia aspernatur dolore fugiat nam voluptate maxime suscipit et. Assumenda labore quia voluptatem cum illo labore. Nobis rerum occaecati dignissimos rem ut et. Saepe consectetur inventore aperiam accusantium nihil.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(34, NULL, '1985-12-25 02:07:10', 'Dolore aut ipsum accusantium omnis qui ea.', 1, 'Officiis quos at magni ut fugiat.', 13, 'Voluptatibus esse aut inventore eum similique. Nesciunt earum dolor corporis. Aspernatur laboriosam placeat et architecto impedit.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(35, NULL, '2011-12-24 02:00:38', 'Sapiente ea qui dolorem rerum ipsam.', 1, 'Minima laboriosam officiis id distinctio.', 436, 'Est laboriosam voluptas sit voluptatem omnis delectus ducimus. Magnam ut aut autem. Rerum aperiam consectetur alias minima laborum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(36, NULL, '2013-02-18 23:22:00', 'Error iusto doloremque aliquam et numquam sunt quasi.', 1, 'Recusandae hic veritatis et sint inventore voluptas.', 371, 'Doloremque sunt aspernatur ipsam adipisci. Sapiente cumque nihil ipsam perspiciatis quia. Eius nihil qui voluptas.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(37, NULL, '1996-08-14 03:19:39', 'Provident reprehenderit fugit saepe.', 1, 'Similique quisquam necessitatibus veritatis quae et vitae eos aspernatur.', 299, 'Magnam est et ut in itaque rem et. Aliquam exercitationem ut explicabo est quia voluptatem consequatur. Quo harum placeat et ut voluptate vel. Animi nam magnam repellat quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(38, NULL, '2013-07-17 23:31:38', 'Pariatur doloremque facilis est quaerat.', 1, 'Sunt et deleniti quod ad voluptatem explicabo omnis.', 285, 'Quasi ut quia illo. Et consequuntur commodi in maxime maxime rem commodi ea. Aut odit nemo omnis officiis earum sed.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(39, NULL, '2012-08-22 21:19:41', 'Rerum porro id inventore.', 1, 'Omnis dolorem autem vitae sit incidunt iusto.', 274, 'Molestias doloremque consectetur dolores eveniet sint. Eveniet eum beatae sint earum magni. Pariatur vero iste ut officia. Repellendus quis totam tempora adipisci.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(40, NULL, '1977-11-23 13:14:33', 'Ad iste sequi dolores ab dolore dolor.', 1, 'Nobis voluptatem nisi excepturi nostrum eligendi culpa.', 237, 'Unde repellendus id voluptatibus dolor autem. Quidem maiores et fugiat et quo. Maxime magnam in quia commodi. Nobis odio deserunt id alias earum exercitationem quidem repudiandae.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(41, NULL, '2000-07-11 04:37:09', 'Eveniet hic esse facilis ut excepturi.', 1, 'Natus enim ut rerum maiores sapiente.', 175, 'Ex aut neque quia ut qui tenetur quo dignissimos. Labore voluptatem voluptatem impedit illum et. Accusamus dolorum iure distinctio sit. Saepe mollitia eius ducimus excepturi accusamus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(42, NULL, '2017-01-16 05:49:28', 'Aperiam illum praesentium quisquam modi qui fugiat.', 1, 'Fuga molestiae tempora facere.', 384, 'Explicabo voluptate non error rerum et delectus. Nemo non voluptatem et eius illo in perspiciatis veniam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(43, NULL, '1970-02-13 13:42:08', 'Voluptas quo impedit delectus.', 1, 'Laboriosam impedit voluptas dignissimos voluptatem ut.', 134, 'Et ut nam autem voluptas inventore dolorem cum. Non quia nisi perspiciatis illum. Ullam iure saepe expedita dolores.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(44, NULL, '1980-12-28 00:45:18', 'Mollitia culpa eius aut ipsa doloremque.', 1, 'Qui est sunt beatae doloremque quae ea.', 490, 'Voluptatibus deleniti vero cupiditate ducimus est. Ea blanditiis et molestiae autem corrupti laboriosam debitis fugit. Blanditiis mollitia repudiandae et quaerat tempora ut natus. Sit sunt ut eum ut dolor.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(45, NULL, '1971-09-09 20:12:56', 'Rerum suscipit nihil tenetur minus aut animi.', 1, 'Vel libero maiores dolor necessitatibus voluptatum.', 130, 'Vel blanditiis dolores quia quibusdam consequatur nesciunt. Maxime fugiat consequatur cupiditate non odio porro velit. Quisquam tenetur sed est omnis quos.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(46, NULL, '2014-06-01 01:34:44', 'Quis ducimus ab officiis officiis recusandae sed.', 1, 'Doloribus ducimus non inventore vel et quam illum.', 407, 'Et dolor sequi non quam eum tempore possimus. Odit est eveniet inventore veniam. Repudiandae ut laboriosam qui aliquid fugiat mollitia.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(47, NULL, '2015-05-10 13:10:22', 'Sit tempore nihil nihil non voluptate.', 1, 'Voluptas quasi molestias nostrum illo nostrum.', 32, 'Qui perferendis repudiandae dolorem sapiente expedita dolores quos. Harum aspernatur quidem nisi odio. Aspernatur perspiciatis enim repellendus voluptatibus perferendis ad quo. Quia sed ipsum officia officiis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(48, NULL, '1975-09-14 10:47:58', 'Officia hic omnis id aliquid blanditiis.', 1, 'Quasi provident earum ea sit autem.', 268, 'Qui sunt recusandae soluta consequatur dolores quis. Dignissimos neque et aut alias ut et. Consequatur ipsum est ipsum molestias.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(49, NULL, '2013-11-21 15:39:23', 'Fuga sed ipsam voluptatibus.', 1, 'Est cum totam repellendus alias.', 307, 'Assumenda corrupti hic est. Ut ut atque error fuga consectetur debitis. Provident illo explicabo est accusamus. Nostrum aspernatur quia voluptatem quia voluptatem assumenda accusantium est.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(50, NULL, '2000-05-24 07:37:10', 'Assumenda et voluptatum voluptatum tenetur sint.', 1, 'Quo nam beatae numquam perferendis.', 310, 'Optio corporis quidem dolores in repellendus nihil necessitatibus explicabo. Ipsam ducimus nesciunt enim fugiat in exercitationem voluptas. Aut enim distinctio minima et qui ut.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(51, NULL, '2020-10-18 02:56:24', 'Quis est similique saepe quibusdam aut.', 1, 'Mollitia consectetur magni sequi odio dolorem esse voluptatibus veritatis.', 141, 'Vero voluptates culpa neque quisquam id quo voluptate vero. Tenetur possimus voluptas eius optio asperiores sit et. Necessitatibus autem dolor in voluptas odit laboriosam. Possimus voluptatibus vero veritatis in cumque non reprehenderit dolore.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(52, NULL, '1983-11-04 13:55:36', 'Molestiae explicabo cupiditate dolor blanditiis unde qui.', 1, 'Unde et voluptatibus deserunt tenetur rerum deserunt.', 406, 'Ut vel aut dicta dolorem non eum omnis. Beatae iste sapiente magni nisi incidunt. Ut est vel tempora tempore animi aut. Omnis distinctio sint harum delectus earum unde.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(53, NULL, '1975-07-18 16:11:14', 'Sint nulla sed dolor laboriosam aperiam commodi labore quod.', 1, 'Iusto atque laborum deserunt voluptates soluta provident.', 275, 'Cumque consequatur quia quos maxime. Maxime eveniet sunt vel velit quia sint vero. Est vitae ipsam minus qui eius aut. Eveniet cum quos sapiente eligendi id quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(54, NULL, '2016-06-10 10:25:48', 'Dolor alias atque aspernatur iste est.', 1, 'Expedita eum eum consequatur minima nostrum blanditiis.', 483, 'Aspernatur aut eaque quod labore dolor fugit. Iusto et veritatis veritatis laudantium voluptas eos. Quasi labore molestiae et doloremque facilis quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(55, NULL, '1976-01-28 19:15:50', 'Veritatis earum eos ut enim in soluta nam.', 1, 'Laudantium veritatis similique consequuntur qui alias tempore.', 89, 'Ducimus inventore veniam voluptatem. Temporibus quis repudiandae cupiditate pariatur. Qui laboriosam modi aut maxime voluptas nemo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(56, NULL, '1974-02-03 14:18:57', 'Quia ex est suscipit eveniet alias necessitatibus.', 1, 'Earum laborum nemo quia iusto accusantium soluta et nihil.', 22, 'Similique maxime quos aut impedit ut. Eaque ut odio architecto ut. At sit adipisci quisquam inventore quia.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(57, NULL, '2016-06-29 06:50:34', 'Harum quis asperiores dolorem aut earum.', 1, 'Inventore consequatur qui id pariatur dolores eaque debitis.', 388, 'Sed id deserunt excepturi qui esse sapiente. Necessitatibus asperiores quasi unde aliquam. Hic repellendus praesentium aliquid facere. Itaque saepe autem debitis nobis libero ut omnis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(58, NULL, '1981-06-14 23:18:13', 'Aliquid eum sed quas quia qui iure.', 1, 'Dolor harum debitis quis.', 498, 'Est aperiam quam voluptatem eius nam nobis. Quam fuga ex rerum non repudiandae non doloremque. Cum animi illum itaque quia laboriosam soluta impedit.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(59, NULL, '2016-08-23 11:53:29', 'Esse rerum tenetur ipsa fuga esse nobis omnis.', 1, 'Totam voluptate et et.', 114, 'Perspiciatis fugiat est reprehenderit blanditiis quia quis reiciendis. Dolores ab consequatur aut doloremque. Officiis reiciendis est quidem perferendis facilis voluptatem. Aut occaecati in quia autem.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(60, NULL, '1971-11-29 21:40:59', 'Ut beatae ipsum non autem deleniti ex quas.', 1, 'Quo est deserunt aut atque.', 197, 'Qui sed enim vel nemo harum. Id id enim repellendus tempore.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(61, NULL, '2016-03-20 17:23:42', 'Officia eligendi vitae animi molestiae dolor veritatis repellat.', 1, 'Illum nisi quo unde ut et.', 367, 'Vero sit perferendis neque ut in. Quia qui molestias tenetur id voluptatem saepe tempora. Ex molestias quo ut quia vero quo.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(62, NULL, '2015-06-30 08:27:06', 'Itaque unde et ut est error ex laudantium alias.', 1, 'Totam consequatur eos facilis quisquam.', 96, 'Voluptatem pariatur non id est. Consequatur ad ut soluta. Suscipit quis vero eum officiis tempora soluta.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(63, NULL, '1985-04-06 00:45:41', 'Provident et voluptas sint ipsam.', 1, 'Minus facere doloribus vitae rem voluptatem tempora illo.', 42, 'Similique accusantium et ipsa pariatur impedit. Occaecati magnam nisi porro reiciendis saepe libero. Quis odit corporis explicabo autem incidunt. Fuga recusandae ratione ex provident rerum sequi illum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(64, NULL, '2016-01-10 08:41:20', 'Eum sit asperiores voluptates voluptatum ipsa et quia dolore.', 1, 'Eligendi aperiam tempore necessitatibus incidunt dolore.', 92, 'Quibusdam voluptatem aut sed porro officiis delectus adipisci eos. Sed quia voluptatem non architecto et vitae dolorem. Reprehenderit enim fugiat minus et eum labore quisquam voluptatibus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(65, NULL, '2005-10-30 10:21:27', 'Et inventore ad quidem aut nam.', 1, 'Excepturi porro possimus animi omnis id quidem quis.', 31, 'Quia enim suscipit mollitia veniam culpa molestias. Est ratione harum qui ea repudiandae asperiores voluptatem sint. Asperiores necessitatibus commodi quaerat id est et. Molestias earum et aliquid velit praesentium blanditiis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(66, NULL, '2002-11-25 17:21:59', 'Neque ea impedit mollitia velit ut.', 1, 'Saepe sit nobis modi unde.', 81, 'Voluptatem facere maxime eos iste tempore vitae in. Praesentium vel alias alias illo praesentium. Ut modi quaerat fuga aut et architecto quis est. Minus magni et nemo aut quae nisi ea consequatur.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(67, NULL, '2006-12-05 01:29:05', 'Laboriosam ab adipisci quia aspernatur eveniet rem quis.', 1, 'Ratione voluptatem provident tempora nemo.', 261, 'Non debitis autem hic aut voluptatibus reiciendis. Sit necessitatibus nam temporibus ut velit sequi. Sed autem deleniti reiciendis aut quis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(68, NULL, '1994-05-03 11:35:49', 'Vel sit dicta eos eaque facere.', 1, 'Quia ullam non minima consequatur excepturi.', 414, 'Atque cum nam doloremque. Ullam ipsa unde iure fuga sint qui. Qui nulla est eligendi sunt nihil.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(69, NULL, '1998-04-01 02:01:29', 'Illum quis id expedita minima corporis neque similique.', 1, 'Eum aut tenetur voluptatem quia consequatur.', 267, 'Est adipisci eos aspernatur consequatur fugiat. Qui laborum necessitatibus voluptatibus tempora.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(70, NULL, '1972-01-18 20:28:08', 'Omnis maiores placeat sed porro ipsa occaecati.', 1, 'Nisi saepe eum quaerat officiis in alias aut.', 284, 'Ut laboriosam sint quo architecto molestiae. Autem magnam odio adipisci perspiciatis ut perferendis accusamus. Commodi quis quo nam est ipsa omnis corporis. Officia repudiandae voluptatem saepe est rerum eius rerum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(71, NULL, '2001-09-01 08:42:00', 'Consequatur est perspiciatis magnam sunt porro.', 1, 'Voluptas earum sed commodi ipsa.', 34, 'Doloremque provident magni nostrum. Voluptas qui perspiciatis ut cum ipsum optio. Dolorem quasi fugiat natus eum. Modi facere sit ea voluptas. Iste et temporibus et velit sit iste.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(72, NULL, '2018-11-23 08:03:41', 'Impedit qui sed laborum in.', 1, 'Incidunt et deleniti dolores reiciendis quo consequatur.', 214, 'Voluptatem a quod non rerum hic nihil. Est culpa est magni id vitae et vel reprehenderit. Et itaque reprehenderit nulla molestiae.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(73, NULL, '1980-06-15 21:13:20', 'Ex incidunt velit aut perspiciatis eaque.', 1, 'Adipisci explicabo reiciendis commodi error.', 167, 'Sint sunt aliquam voluptas ut quas omnis deserunt. Illum similique aut asperiores aspernatur suscipit cumque.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(74, NULL, '1972-04-14 07:15:16', 'Et ex minus quia sed ratione sit.', 1, 'Distinctio ea nesciunt ut non ea.', 339, 'Possimus accusantium consectetur voluptatum exercitationem cupiditate odit aut. Est deleniti maxime autem id et enim doloribus. Rerum magni aspernatur qui et aut labore est. Dignissimos ipsa sint libero quaerat voluptate omnis incidunt fugiat.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(75, NULL, '2015-06-07 19:00:07', 'Rerum rerum earum maxime mollitia numquam rem.', 1, 'Aut enim dolorem quibusdam dolore.', 451, 'Nobis omnis eum inventore natus quasi sint vero omnis. Quia cumque est tenetur libero fuga.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(76, NULL, '2025-01-08 07:39:58', 'Rem sequi alias corporis et quis.', 1, 'Quos corrupti soluta provident eveniet illo.', 431, 'Non molestiae consequuntur asperiores. Nesciunt esse iste quia.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(77, NULL, '1986-04-12 06:48:46', 'Natus quae nobis omnis at ut.', 1, 'Aliquid hic eaque dolores.', 226, 'Accusantium porro recusandae perspiciatis et optio vero. Voluptas ut similique quo non. Nesciunt repellendus itaque beatae perferendis pariatur hic. Accusamus aut ratione dolor placeat error. Qui non possimus beatae animi dolor voluptatem fuga.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(78, NULL, '1989-07-09 15:09:13', 'Incidunt consequatur maiores delectus explicabo unde vel magni.', 1, 'Ut accusamus id et.', 30, 'Rerum est eum explicabo ad sit ratione labore. Aut ipsa hic quas ullam. Asperiores voluptatem rerum vel qui. Excepturi voluptas molestiae accusamus quia.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(79, NULL, '2006-01-06 12:59:24', 'Dolores rerum id fugit repudiandae sit.', 1, 'Sit quia quod mollitia ut voluptates nostrum aut adipisci.', 454, 'Omnis sit odit dolorem vero dolorum aspernatur. Itaque voluptas sit vel. Eos qui cupiditate veritatis autem dolorem et. Labore officia deleniti beatae nobis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(80, NULL, '1992-03-20 14:05:45', 'Quos iste qui asperiores excepturi.', 1, 'Quo vero recusandae id quia dolor deserunt sequi sit.', 112, 'Ab qui ut numquam consequatur ut impedit odio. Accusantium numquam culpa impedit eveniet maiores deserunt voluptatum recusandae.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(81, NULL, '2011-09-09 13:28:00', 'Et eius explicabo necessitatibus.', 1, 'Laboriosam inventore inventore ducimus qui dolore voluptatibus.', 222, 'Est magnam ipsa quisquam error hic. Voluptatem soluta est rerum tempore. Asperiores nam omnis et quis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(82, NULL, '2022-12-23 18:31:09', 'Omnis officiis autem repudiandae dignissimos.', 1, 'Eum quia dicta numquam ab omnis sint.', 26, 'Est quisquam delectus ut repellendus quia aperiam. Similique dolores unde maxime quis ut fugiat sed aut. Recusandae voluptates doloremque ad voluptatem.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(83, NULL, '2008-01-14 01:28:17', 'Excepturi voluptas labore sunt sed.', 1, 'Quo repudiandae tenetur harum velit eveniet voluptatem.', 234, 'Illum recusandae blanditiis ratione. Officia tempore modi vel in. Nostrum quis accusantium quam dolorum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(84, NULL, '2008-08-21 14:53:40', 'Magnam temporibus sunt id repellendus aut praesentium minima.', 1, 'Eos distinctio inventore numquam dolorem velit.', 412, 'Minus velit consectetur harum optio qui. Optio nam ut voluptatem. Delectus velit possimus alias.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(85, NULL, '1997-05-12 14:23:30', 'Dignissimos et sit consequuntur consequatur earum sequi.', 1, 'Sint repellat qui est quis consequatur optio quae.', 454, 'Quis et rerum a qui. Voluptas exercitationem maxime rerum delectus ad. Accusamus et pariatur cupiditate.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(86, NULL, '1983-07-10 13:51:27', 'Exercitationem veniam voluptatem quia nisi vero.', 1, 'Aut omnis aut ut repellat saepe reprehenderit nam.', 445, 'At repellat voluptatibus nobis sapiente. Accusamus ut nihil tempora est aliquid harum odio. Aut voluptatem vitae quam. Iusto necessitatibus voluptatem ipsam eligendi quia quis consequuntur nihil.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(87, NULL, '2001-03-22 12:10:29', 'Distinctio saepe voluptatem in reiciendis alias mollitia.', 1, 'Porro accusamus nulla est impedit dicta dolore.', 404, 'Nihil animi cum et quam voluptatem. Vel quisquam dolor voluptatem porro molestiae qui error. Ut ullam ratione reiciendis aut omnis aut.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(88, NULL, '2016-12-11 09:50:50', 'Aliquid unde tempore sunt dicta quo et.', 1, 'Culpa consequatur est facilis repellendus dolorum ea voluptas.', 309, 'Fugiat rerum repellat nam architecto qui molestias eum. Enim maiores aut ipsam nihil voluptas. Ea quisquam ipsa enim omnis.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(89, NULL, '1970-04-30 09:59:17', 'Minus voluptates laboriosam distinctio voluptas odio voluptas.', 1, 'Pariatur natus atque molestiae neque incidunt.', 46, 'Nihil sint facilis quia ipsa similique dolorum quidem. Eveniet porro architecto accusamus dolores sapiente. Voluptate est illum id quos cum nobis facere accusamus. Et aut voluptatem doloremque omnis voluptatibus ipsum eos. Illo est recusandae necessitatibus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(90, NULL, '2000-05-30 14:10:16', 'Fugit qui ullam aut accusamus animi ipsa.', 1, 'Optio enim animi nobis quam.', 458, 'Ipsa dolorum repellendus est. Quisquam voluptates sit ad aut error. Eum adipisci laudantium quam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(91, NULL, '2020-11-22 06:18:20', 'Tenetur aut illo dolores voluptas.', 1, 'Natus neque impedit eum corporis nostrum totam.', 86, 'Quos et recusandae aperiam vel quia repudiandae sint. Rerum omnis rerum ut similique et. Perferendis eaque laboriosam eos facere accusantium tenetur veritatis. Quia consequatur deleniti ullam illo fugit non vero.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(92, NULL, '1979-06-21 07:41:27', 'Quibusdam sit ratione dolorem quibusdam tenetur facere et.', 1, 'Natus iure modi neque dolores rem eos occaecati a.', 446, 'Nam voluptate omnis omnis amet perferendis. Facilis et blanditiis porro voluptatem illo. Quod enim qui similique molestias placeat.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(93, NULL, '2017-01-21 03:56:08', 'Labore facilis tempore voluptas minima.', 1, 'Et est laborum exercitationem commodi alias veniam reprehenderit sed.', 290, 'Et maxime minus a id. Eum natus sed veritatis et labore. Laboriosam qui autem assumenda perspiciatis sapiente dolorem.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(94, NULL, '2022-05-04 13:41:02', 'Quod quis nostrum repellendus quis velit necessitatibus.', 1, 'Dolores eligendi reiciendis possimus qui at in.', 177, 'Quae placeat officia rerum aspernatur hic omnis atque. Iste illo ipsam corporis deserunt nihil saepe soluta. In consequatur dolor laboriosam.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(95, NULL, '1971-10-20 21:22:04', 'Sit tempore veniam aliquam nisi velit.', 1, 'Quia animi libero ab recusandae est quod voluptatibus.', 408, 'Molestiae consequatur ullam iste animi quis at. Nihil accusamus quod sint sit. Qui quis aliquam harum minima praesentium illo fuga dolor. Veniam eos sapiente ipsa dolores autem harum.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(96, NULL, '1994-08-21 22:49:08', 'Quidem eum at mollitia iste harum rerum.', 1, 'Expedita adipisci aut dolor maiores.', 33, 'At eos voluptas aperiam quae velit error id. Perspiciatis ad beatae veritatis temporibus voluptas temporibus quo. Nostrum quia exercitationem voluptatem molestias.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(97, NULL, '1994-08-30 06:02:00', 'Nulla necessitatibus labore rerum autem id officia.', 1, 'Eaque dolor magni quis et et delectus.', 52, 'Quis odio voluptatem nobis qui sit quas quod. Eligendi voluptatem ad voluptate maxime sit molestias voluptatem. Dolores quia tempora consectetur adipisci ducimus.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(98, NULL, '2018-05-06 02:13:20', 'Iusto repellat est amet id labore vitae dolor.', 1, 'Exercitationem voluptas qui aut voluptatum culpa quae hic.', 395, 'In animi aliquid culpa voluptatem. Rerum enim aliquid aut.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(99, NULL, '2013-11-09 21:37:16', 'Ducimus temporibus eius iure expedita et rerum quasi.', 1, 'Dolores placeat illum atque explicabo.', 198, 'Ex omnis placeat exercitationem. Exercitationem omnis ipsum sit distinctio ipsa sint dignissimos. Quo eligendi eos alias quas est velit ratione rerum. Ea vel sapiente voluptas voluptatum ratione.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL),
(100, NULL, '2012-02-24 22:44:22', 'Quia libero nemo expedita natus.', 1, 'Dolorum unde deleniti minus voluptatem ducimus ut debitis.', 391, 'Enim aut accusantium excepturi beatae aut voluptatem. Dolores voluptatibus fuga vel laborum quis mollitia illo. Pariatur odio blanditiis sit ut vitae a. Mollitia aut impedit aut dicta dolore repellat.', 1, 'escola', NULL, NULL, '2025-03-24 09:58:54', '2025-03-24 09:58:54', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `log_name` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_type` varchar(255) DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `causer_type` varchar(255) DEFAULT NULL,
  `causer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`properties`)),
  `batch_uuid` char(36) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairros`
--

CREATE TABLE `bairros` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `municipios_id` bigint(20) UNSIGNED NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('arturjose0@gmail.com|105.168.155.146', 'i:1;', 1743847433),
('arturjose0@gmail.com|105.168.155.146:timer', 'i:1743847433;', 1743847433),
('cristina.espinoza.c@gmail.com|90.77.236.224', 'i:1;', 1743583356),
('cristina.espinoza.c@gmail.com|90.77.236.224:timer', 'i:1743583356;', 1743583356),
('daniel.francisco@unipiaget-angola.org|41.63.189.155', 'i:2;', 1743448516),
('daniel.francisco@unipiaget-angola.org|41.63.189.155:timer', 'i:1743448516;', 1743448516),
('fasma@streaming.ao|105.168.155.146', 'i:1;', 1743847400),
('fasma@streaming.ao|105.168.155.146:timer', 'i:1743847400;', 1743847400),
('josearturkassala0@gmail.com|105.168.155.146', 'i:3;', 1743847475),
('josearturkassala0@gmail.com|105.168.155.146:timer', 'i:1743847475;', 1743847475);

-- --------------------------------------------------------

--
-- Estrutura da tabela `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ch_favorites`
--

CREATE TABLE `ch_favorites` (
  `id` char(36) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `favorite_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ch_messages`
--

CREATE TABLE `ch_messages` (
  `id` char(36) NOT NULL,
  `from_id` bigint(20) NOT NULL,
  `to_id` bigint(20) NOT NULL,
  `body` varchar(5000) DEFAULT NULL,
  `attachment` varchar(255) DEFAULT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `ch_messages`
--

INSERT INTO `ch_messages` (`id`, `from_id`, `to_id`, `body`, `attachment`, `seen`, `created_at`, `updated_at`) VALUES
('0b092998-03de-4169-abc1-bb03ee936f36', 12, 7, 'ol&aacute; sabino', NULL, 1, '2025-03-25 09:05:07', '2025-03-25 09:05:13'),
('12b98e59-02be-422c-950b-19eb4e15e732', 1, 12, 'oi', NULL, 1, '2025-03-25 09:01:32', '2025-03-25 09:01:47'),
('240f03e7-b6f5-4bec-b6f5-1feda0f7f4cf', 7, 1, 'Meu', NULL, 1, '2025-03-25 09:01:40', '2025-03-25 09:01:45'),
('24cf518d-923f-4308-bfbd-a06618941ef7', 1, 7, 'O que achou_', '{\"new_name\":\"f439ea0e-c43f-4a62-a7e6-25ce9d8bb712.jpg\",\"old_name\":\"Hospital Municipal do Cubal.jpg\"}', 1, '2025-03-25 09:02:20', '2025-03-25 09:02:21'),
('466ef538-3f0f-4097-9419-a9bfc41d8d1d', 7, 7, 'Ol&aacute; pessoal', NULL, 1, '2025-03-25 08:59:03', '2025-03-25 09:00:01'),
('7383c028-5b44-4a01-95ca-e84828c799ea', 7, 1, 'Recebido', NULL, 1, '2025-03-25 09:02:37', '2025-03-25 09:02:37'),
('ac06663c-5419-4857-9f74-44776d77751e', 8, 8, 'Bom dia, estimado colegas do projecto Chance.', NULL, 1, '2025-03-25 09:00:57', '2025-03-25 09:03:45'),
('bf8384d3-5533-42b2-b396-02732fab7fb4', 7, 12, 'Obaaaaa minha mana', NULL, 1, '2025-03-25 09:05:25', '2025-03-25 09:05:33'),
('ce349e69-298d-4ce5-b4dc-c4324777d1dd', 12, 1, 'oi', NULL, 1, '2025-03-25 09:02:10', '2025-03-25 09:03:23');

-- --------------------------------------------------------

--
-- Estrutura da tabela `controle_de_acessos`
--

CREATE TABLE `controle_de_acessos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `painelControle` varchar(4) DEFAULT NULL,
  `grupodeaccesso` varchar(4) DEFAULT NULL,
  `utilizadores` varchar(4) DEFAULT NULL,
  `unidadesSanitarias` varchar(4) DEFAULT NULL,
  `escolas` varchar(4) DEFAULT NULL,
  `eventos` varchar(4) DEFAULT NULL,
  `chat` varchar(4) DEFAULT NULL,
  `arquivos` varchar(4) DEFAULT NULL,
  `projectos` varchar(4) DEFAULT NULL,
  `perfil` varchar(4) DEFAULT NULL,
  `mapa` varchar(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `controle_de_acessos`
--

INSERT INTO `controle_de_acessos` (`id`, `nome`, `painelControle`, `grupodeaccesso`, `utilizadores`, `unidadesSanitarias`, `escolas`, `eventos`, `chat`, `arquivos`, `projectos`, `perfil`, `mapa`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', 'crud', '2025-03-24 09:58:51', '2025-03-24 09:58:51'),
(2, 'Convidado', NULL, NULL, NULL, 'r', 'r', 'r', NULL, 'r', 'r', 'ru', 'r', '2025-03-24 09:58:51', '2025-03-24 09:58:51'),
(3, 'Owner', 'r', NULL, 'r', 'r', 'r', 'r', 'r', NULL, NULL, NULL, NULL, '2025-03-24 13:46:28', '2025-03-24 13:46:28'),
(4, 'Admin', 'r', NULL, 'cr', 'r', 'r', 'r', 'r', NULL, NULL, NULL, NULL, '2025-03-24 13:47:32', '2025-03-24 13:47:32'),
(5, 'Professores', '', NULL, '', 'r', 'r', 'r', 'r', NULL, NULL, NULL, NULL, '2025-03-24 13:48:12', '2025-03-24 13:48:12'),
(6, 'Profissionais de Saúde', '', NULL, '', 'r', 'r', 'r', 'r', NULL, NULL, NULL, NULL, '2025-03-24 13:48:56', '2025-03-24 13:48:56');

-- --------------------------------------------------------

--
-- Estrutura da tabela `curricula`
--

CREATE TABLE `curricula` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cadeira` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curriculos_escolas`
--

CREATE TABLE `curriculos_escolas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `escolas_id` bigint(20) UNSIGNED NOT NULL,
  `curriculum_id` bigint(20) UNSIGNED NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `escolas`
--

CREATE TABLE `escolas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL COMMENT 'nome da escola',
  `provincia` varchar(255) DEFAULT NULL,
  `municipio` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `coordinates` point DEFAULT NULL COMMENT 'podemos mais tarde integrar com o google map',
  `latitude` decimal(10,8) NOT NULL COMMENT 'google map',
  `longitude` decimal(10,8) NOT NULL COMMENT 'google map',
  `n_a_primario_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no ensino primario',
  `n_a_primario_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no ensino primario',
  `n_a_primeiroCiclo_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no primeiro ciclo (7 a 9 classe)',
  `n_a_primeiroCiclo_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no primeiro ciclo (7 a 9 classe)',
  `n_a_segundoCiclo_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no segundo ciclo (ensino medio)',
  `n_a_segundoCiclo_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de estudantes no segundo ciclo (ensino medio)',
  `n_p_segundoCiclo_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no segundo ciclo (ensino medio)',
  `n_p_segundoCiclo_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no segundo ciclo (ensino medio)',
  `n_p_superior_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no ensino superior',
  `n_p_superior_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no ensino superior',
  `n_p_posgraduacao_homem` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no pos-graduacao',
  `n_p_posgraduacao_mulher` int(11) NOT NULL DEFAULT 0 COMMENT 'numero de professores no pos-graduacao',
  `turno_manha` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'periodo de trabalho',
  `turno_tarde` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'periodo de trabalho',
  `turno_noite` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'periodo de trabalho',
  `privado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'tipo de escola',
  `publica` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'tipo de escola',
  `saudesexual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Inclusão de questões de saúde sexual e reprodutiva',
  `descriminacao` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `aguacorrente` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `casadebanho` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `productosmenstruais` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `postomedico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `dignidademenstrual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `gravidezprecoce` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `gabinetepsicologico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `responsavel` varchar(200) DEFAULT NULL,
  `telefone` varchar(14) DEFAULT NULL,
  `celular` varchar(14) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `imagem` varchar(255) DEFAULT NULL,
  `ficha` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `escolas`
--

INSERT INTO `escolas` (`id`, `nome`, `provincia`, `municipio`, `bairro`, `coordinates`, `latitude`, `longitude`, `n_a_primario_homem`, `n_a_primario_mulher`, `n_a_primeiroCiclo_homem`, `n_a_primeiroCiclo_mulher`, `n_a_segundoCiclo_homem`, `n_a_segundoCiclo_mulher`, `n_p_segundoCiclo_homem`, `n_p_segundoCiclo_mulher`, `n_p_superior_homem`, `n_p_superior_mulher`, `n_p_posgraduacao_homem`, `n_p_posgraduacao_mulher`, `turno_manha`, `turno_tarde`, `turno_noite`, `privado`, `publica`, `saudesexual`, `descriminacao`, `aguacorrente`, `casadebanho`, `productosmenstruais`, `postomedico`, `dignidademenstrual`, `gravidezprecoce`, `gabinetepsicologico`, `responsavel`, `telefone`, `celular`, `email`, `estado`, `imagem`, `ficha`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Colégio Missionária BG Nº 2019 São Paulo Bela Vista', 'Benguela', 'Lobito', 'Bela Vista', NULL, -12.36929600, 13.57052500, 0, 0, 863, 937, 0, 0, 0, 0, 40, 48, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 'Mateus Florindo Leonardo', '923405317', '924486803', NULL, 1, '/storage/imagens/3dh0LX5K28.jpg', NULL, '2025-03-24 10:43:02', '2025-03-24 10:43:02', NULL),
(2, 'Escola Primária BG Nº 2012 Evangélica da Canata', 'Benguela', 'Lobito', 'BAIRRO LIRO', NULL, -12.36503300, 13.56525200, 0, 0, 1235, 1215, 0, 0, 0, 0, 41, 64, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 'Teresa Nawandi Binbi Lianda', '930107589', '927806995', NULL, 1, '/storage/imagens/6AT2rQ2LE2.jpg', NULL, '2025-03-24 11:00:19', '2025-03-24 11:00:19', NULL),
(3, 'Escola Primária BG Nº  20186 Doutor  A. Neto', 'Benguela', 'Lobito', 'BAIRRO LIRO', NULL, -12.35655700, 13.57017100, 0, 0, 356, 321, 0, 0, 0, 0, 2, 25, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'José Gonçalves', '926461802', '958499460', NULL, 1, NULL, NULL, '2025-03-24 11:14:41', '2025-03-24 11:14:41', NULL),
(4, 'Complexo Escolar Evangélico BG 2008 da Galileia', 'Benguela', 'Lobito', 'LOBITO ZONA 4 BAIRO SANTA CRUZ', NULL, -12.40030900, 13.55023700, 0, 0, 2, 794, 379, 415, 0, 0, 18, 20, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 'Anibal Chicale', NULL, NULL, NULL, 1, '/storage/imagens/H8GXVUr668.jpg', NULL, '2025-03-24 11:35:35', '2025-03-24 11:35:35', NULL),
(5, 'Colégio Público Bg nº 2011 Said Mingas', 'Benguela', 'Lobito', 'Compâo, ZONA 1, LOBITO', NULL, -12.35985400, 13.53714000, 1000, 1004, 1046, 958, 0, 0, 0, 0, 27, 66, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 'Cecília Faustino José', '945351386', '923735883', NULL, 1, '/storage/imagens/MtOmBw8y5G.jpg', NULL, '2025-03-24 11:49:32', '2025-03-24 11:49:32', NULL),
(6, 'Complexo Escolar 2091 Agostinho Epalanga', 'Benguela', 'Lobito', 'ZONA 1 BAIRRO CABAIA SALINAS', NULL, -12.37488200, 13.51747100, 0, 0, 241, 276, 0, 0, 0, 0, 4, 16, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'Januário Jonas Kabuto', '924051463', NULL, NULL, 1, '/storage/imagens/4y5bMq1qsn.jpg', NULL, '2025-03-27 14:03:20', '2025-03-27 14:03:20', NULL),
(7, 'Complexo Escolar 2010 Sagrada Esperança', 'Benguela', 'Lobito', 'Bairro 28, ZONA 1', NULL, -12.34926400, 13.54400500, 450, 850, 0, 0, 0, 0, 0, 0, 2, 34, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 'Gelberto Catumbela Arão Joaquim', '938722371', '923785467', NULL, 1, '/storage/imagens/HpoWuOxNku.jpg', NULL, '2025-03-27 14:29:27', '2025-03-27 14:29:27', NULL),
(8, 'Colégio Público BG Nº 2015 Rei Mandume', 'Benguela', 'Lobito', 'BAIRRO SANTA CRUZ - VILA', NULL, -12.39556300, 13.55199800, 0, 0, 1472, 860, 0, 0, 0, 0, 27, 57, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'N/D', 'N/D', NULL, NULL, 1, '/storage/imagens/o8OLd7TNmZ.jpg', NULL, '2025-03-27 14:57:59', '2025-03-27 14:57:59', NULL),
(9, 'Escola Primária BG Nº 2416 Comandante Kassanji', 'Benguela', 'Lobito', 'BAIRRO DA ZÁMBIA', NULL, -12.37822000, 13.58003800, 1963, 2136, 0, 0, 0, 0, 0, 0, 7, 84, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 'Evaristo Samuel', '923483480', NULL, NULL, 1, '/storage/imagens/fgrDlofhnI.jpg', NULL, '2025-03-27 15:45:58', '2025-03-27 15:45:58', NULL),
(10, 'Escola Primária BG 2002 Alto Esperança', 'Benguela', 'Lobito', 'BAIRRO ALTO ESPERANÇA. ZONA 5', NULL, -12.38620800, 13.57576600, 0, 0, 1045, 988, 0, 0, 0, 0, 6, 29, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 'Eduardo Pedro Pacheco Tchivava', '924249860', '917259957', NULL, 1, '/storage/imagens/mI2kpnXp3t.jpg', NULL, '2025-03-28 00:20:41', '2025-03-28 00:20:41', NULL),
(11, 'Colégio Elídio Machado', 'Benguela', 'Cubal', 'Cidade do Cubal, Cubal', NULL, -13.03760000, 14.25272600, 0, 0, 1253, 1083, 0, 0, 0, 0, 82, 36, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 'Mateus Victorino Kupesala', '923021696', NULL, NULL, 1, '/storage/imagens/bLrk7NB5V0.jpg', NULL, '2025-03-28 00:49:25', '2025-03-28 00:49:25', NULL),
(12, 'Complexo Escolar Bg 4016 Teresiana do Cubal', 'Benguela', 'Cubal', 'Cristo Rei, Cubal', NULL, -13.02670200, 14.23073200, 0, 0, 587, 606, 0, 0, 0, 0, 34, 23, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 'Teresa Nacali José', '945826342', NULL, NULL, 1, '/storage/imagens/oWupRbZmI5.jpg', NULL, '2025-03-28 01:39:32', '2025-03-28 01:39:32', NULL),
(13, 'Escola de Formação de Professores BG 4011/Cubal', 'Benguela', 'Cubal', 'Sede, Cubal', NULL, -13.03813500, 14.24620900, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 1, 'Leandro Raquel Candele', '924697493', NULL, NULL, 1, '/storage/imagens/XOx0epex4G.jpg', NULL, '2025-03-28 17:48:08', '2025-03-28 17:48:08', NULL),
(14, 'Escola do I Ciclo e do Ensino Secundário BG 4013 Kilamba', 'Benguela', 'Cubal', NULL, NULL, -13.04170700, 14.23305900, 0, 0, 861, 876, 0, 0, 0, 0, 66, 17, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 'Pedro Angelo Manuel', '924749505', NULL, NULL, 1, '/storage/imagens/O3leNCOmQH.jpg', NULL, '2025-03-28 18:45:31', '2025-03-28 18:45:31', NULL),
(15, 'Instituto Politécnico do Cubal GB nº 4196', 'Benguela', 'Cubal', 'Techimbasse, Cubal', NULL, -13.03204200, 14.27573100, 0, 0, 0, 0, 151, 321, 0, 0, 66, 6, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 'Eduardo Palanga', '923528654', NULL, NULL, 1, '/storage/imagens/UzJY7NysyH.jpg', NULL, '2025-03-28 19:21:24', '2025-03-28 19:21:24', NULL),
(16, 'Instituto Técnico de Saúde BG 4195', 'Benguela', 'Cubal', 'Bairro de CasSIMra, Cubal', NULL, -13.06482000, 14.27039100, 0, 0, 0, 0, 348, 542, 0, 0, 19, 19, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 'Fernanda Graça', '923371408', NULL, NULL, 1, '/storage/imagens/T7OTBWheL2.jpg', NULL, '2025-03-28 19:36:32', '2025-03-28 19:36:32', NULL),
(17, 'Liceu BG Nº 4235 - Cubal', 'Benguela', 'Cubal', 'Cidade do Cubal, Cubal', NULL, -13.03981200, 14.24482400, 0, 0, 0, 0, 722, 593, 0, 0, 46, 15, 0, 0, 1, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 'Tomás Caluneteca Jorge', '923022976', NULL, NULL, 1, '/storage/imagens/zRPQHaZv4F.jpg', NULL, '2025-03-28 19:46:11', '2025-03-28 19:46:11', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionalidades`
--

CREATE TABLE `funcionalidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL COMMENT 'Ex: utilizadores, Posto de saude, etc.',
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs`
--

CREATE TABLE `logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `actividade` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `media`
--

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `mensagens`
--

CREATE TABLE `mensagens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `remetente` bigint(20) UNSIGNED NOT NULL,
  `destinatario` bigint(20) UNSIGNED NOT NULL,
  `mensagem` text NOT NULL,
  `lida` tinyint(1) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0000_08_22_125008_create_niveis_acessos_table', 1),
(2, '0000_2_27_044429_create_controle_de_acessos_table', 1),
(3, '0001_01_01_000000_create_users_table', 1),
(4, '0001_01_01_000001_create_cache_table', 1),
(5, '0001_01_01_000002_create_jobs_table', 1),
(6, '2024_08_22_000004_create_paises_table', 1),
(7, '2024_08_22_000004_create_provincias_table', 1),
(8, '2024_08_22_000005_create_municipios_table', 1),
(9, '2024_08_22_000007_create_bairros_table', 1),
(10, '2024_08_22_000009_create_pessoas_table', 1),
(11, '2024_08_22_000010_create_sectores_table', 1),
(12, '2024_08_22_125010_create_funcionalidades_table', 1),
(13, '2024_08_22_125222_create_permissoes_table', 1),
(14, '2024_08_22_125251_create_postos_saudes_table', 1),
(15, '2024_08_22_125557_create_servicos_postos_table', 1),
(16, '2024_08_22_125728_create_servicoe_posto__posto_saudes_table', 1),
(17, '2024_08_22_125827_create_mensagens_table', 1),
(18, '2024_08_22_173623_create_actividades_table', 1),
(19, '2024_09_05_141812_create_escolas_table', 1),
(20, '2024_09_05_142702_create_logs_table', 1),
(21, '2024_10_09_103044_create_activity_log_table', 1),
(22, '2024_10_09_103045_add_event_column_to_activity_log_table', 1),
(23, '2024_10_09_103046_add_batch_uuid_column_to_activity_log_table', 1),
(24, '2024_10_10_155125_create_media_table', 1),
(25, '2024_10_11_999999_add_active_status_to_users', 1),
(26, '2024_10_11_999999_add_avatar_to_users', 1),
(27, '2024_10_11_999999_add_dark_mode_to_users', 1),
(28, '2024_10_11_999999_add_messenger_color_to_users', 1),
(29, '2024_10_11_999999_create_chatify_favorites_table', 1),
(30, '2024_10_11_999999_create_chatify_messages_table', 1),
(31, '2024_10_29_130612_create_curricula_table', 1),
(32, '2024_10_29_164140_create_curriculos_escolas_table', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `municipios`
--

CREATE TABLE `municipios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `provincias_id` bigint(20) UNSIGNED NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `municipios`
--

INSERT INTO `municipios` (`id`, `nome`, `provincias_id`, `estado`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Lobito', 1, 1, '2025-03-24 09:58:52', '2025-03-24 09:58:52', NULL),
(2, 'Cubal', 1, 1, '2025-03-24 09:58:52', '2025-03-24 09:58:52', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `niveis_acessos`
--

CREATE TABLE `niveis_acessos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `paises`
--

CREATE TABLE `paises` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `nativo` varchar(255) NOT NULL COMMENT 'ex: angolano, portugues',
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `paises`
--

INSERT INTO `paises` (`id`, `nome`, `nativo`, `estado`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Angola', 'Angolano/a', 1, '2025-03-24 09:58:52', '2025-03-24 09:58:52', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `permissoes`
--

CREATE TABLE `permissoes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `niveis_acesso_id` bigint(20) UNSIGNED NOT NULL,
  `funcionalidades_id` bigint(20) UNSIGNED NOT NULL,
  `permissao` varchar(255) NOT NULL COMMENT 'crud onde c create r read u update d delete',
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pessoas`
--

CREATE TABLE `pessoas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `postos_saudes`
--

CREATE TABLE `postos_saudes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `provincia` varchar(255) DEFAULT NULL,
  `municipio` varchar(255) DEFAULT NULL,
  `bairro` varchar(255) DEFAULT NULL,
  `coordinates` point DEFAULT NULL COMMENT 'podemos mais tarde integrar com o google map',
  `latitude` decimal(10,8) NOT NULL COMMENT 'google map',
  `longitude` decimal(10,8) NOT NULL COMMENT 'google map',
  `tipo` varchar(30) NOT NULL,
  `comunidades_servidas` int(11) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `masculino` int(11) NOT NULL DEFAULT 0,
  `feminino` int(11) NOT NULL DEFAULT 0,
  `especialistas` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `n_especialistas` int(11) NOT NULL DEFAULT 0,
  `parteiras` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `homem_especialista` int(11) NOT NULL DEFAULT 0,
  `mulher_especialista` int(11) NOT NULL DEFAULT 0,
  `especialidades` varchar(150) DEFAULT 'N/D',
  `curso_workshop` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `planejamento_familiar` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `preprosnatal` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `conselho_vih` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `cuidados_saude_menstrual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `servico_aborto_seguro` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `educacao_conselho_ssr` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `servico_violencia_genero` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `campanha_prevencao_hiv` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `programas_educacao_ssr` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `iniciativas_formacao_saude_menstrual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `programas_adolescentes_jovens` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `projectos_empoderamento_feminino` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `horas_atencao` varchar(8) DEFAULT NULL,
  `sistema_atendimento_externo` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `unidade_ssr` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `salas_exame_ginecologico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `aconselhamento_psicologico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `ecografia_colposcopia` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `materiais_planejamento` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `materiais_diagnostico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `conservacao` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `privacidade` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `testes_hiv` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `testes_simfilis` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `testes_vhb` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `testes_paludismo` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `testes_gravidez` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `media_pacientes_atendidos_dia` int(11) NOT NULL DEFAULT 0,
  `media_adolescentes_jovens` int(11) NOT NULL DEFAULT 0,
  `distribuicao_gratuita_preservativo` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `quem_oferece` varchar(200) DEFAULT NULL,
  `responsavel` varchar(200) DEFAULT NULL,
  `telefone` varchar(14) DEFAULT NULL,
  `celular` varchar(14) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Em actividade ou nao',
  `imagem` varchar(255) DEFAULT NULL,
  `ficha` varchar(255) DEFAULT NULL,
  `aguacorrente` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `casadebanho` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `productosmenstruais` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `postomedico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `dignidademenstrual` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `gravidezprecoce` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `gabinetepsicologico` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Existência de protocolo contra conflitos , discriminação de género ou gravidez cedo',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `postos_saudes`
--

INSERT INTO `postos_saudes` (`id`, `nome`, `provincia`, `municipio`, `bairro`, `coordinates`, `latitude`, `longitude`, `tipo`, `comunidades_servidas`, `area`, `masculino`, `feminino`, `especialistas`, `n_especialistas`, `parteiras`, `homem_especialista`, `mulher_especialista`, `especialidades`, `curso_workshop`, `planejamento_familiar`, `preprosnatal`, `conselho_vih`, `cuidados_saude_menstrual`, `servico_aborto_seguro`, `educacao_conselho_ssr`, `servico_violencia_genero`, `campanha_prevencao_hiv`, `programas_educacao_ssr`, `iniciativas_formacao_saude_menstrual`, `programas_adolescentes_jovens`, `projectos_empoderamento_feminino`, `horas_atencao`, `sistema_atendimento_externo`, `unidade_ssr`, `salas_exame_ginecologico`, `aconselhamento_psicologico`, `ecografia_colposcopia`, `materiais_planejamento`, `materiais_diagnostico`, `conservacao`, `privacidade`, `testes_hiv`, `testes_simfilis`, `testes_vhb`, `testes_paludismo`, `testes_gravidez`, `media_pacientes_atendidos_dia`, `media_adolescentes_jovens`, `distribuicao_gratuita_preservativo`, `quem_oferece`, `responsavel`, `telefone`, `celular`, `email`, `estado`, `imagem`, `ficha`, `aguacorrente`, `casadebanho`, `productosmenstruais`, `postomedico`, `dignidademenstrual`, `gravidezprecoce`, `gabinetepsicologico`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'CENTRO DE SAUDE GASPAR DM LOPES', 'Benguela', 'Lobito', '17 SETEMBRO', NULL, -12.36918300, 13.59664800, 'Centro Médico', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'ANÁLISE CLÍNICA', 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 'PNUD', 'Fernando J.N Zruz', '923386556', '958533828', NULL, 1, '/storage/imagens/j9yc7bnqOo.jpg', NULL, 1, 1, 0, 0, 0, 1, 1, '2025-03-24 12:25:50', '2025-03-24 12:25:50', NULL),
(2, 'CENTRO MEDICO SANTA TERESA DE JESUS', 'Benguela', 'Lobito', 'SANTA CRUZ', NULL, -12.39579460, 13.55176520, 'Centro Médico', 0, 4, 1, 1, 0, 1, 0, 0, 0, '', 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, NULL, 'Rosa Catumbo', '923661776', NULL, NULL, 1, '/storage/imagens/Hhpqmwqqce.jpg', NULL, 1, 1, 0, 0, 0, 1, 1, '2025-03-24 14:44:04', '2025-03-24 14:44:04', NULL),
(3, 'CENTRO DE SAUDE SEXUAL REPRODUCTIVA AMIGO DO ADOLESCENTE E DO JOVEM', 'Benguela Province', 'Lobito', 'Alto Liro', NULL, -12.37615200, 13.58148600, 'Centro Médico', 0, 7, 0, 16, 0, 1, 0, 0, 1, 'PEDIATRIA', 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 0, 0, NULL, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 140, 32, 1, 'N/D', 'Juliana Mendonça', '923425020', '937795883', NULL, 1, '/storage/imagens/1vryPEwTcB.jpg', NULL, 0, 1, 0, 0, 0, 0, 0, '2025-03-24 16:04:37', '2025-03-24 16:04:37', NULL),
(5, 'CENTRO MÉDICO LUISA DE MARILLAC', 'Benguela', 'Lobito', 'BASSAI', NULL, -12.36411000, 13.53767900, 'Centro Médico', 0, 3, 1, 1, 0, 0, 0, 0, 0, 'N/D', 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, NULL, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 32, 20, 0, NULL, 'Irmã Maria José', '922764044', NULL, NULL, 1, '/storage/imagens/YXyfGkz9WR.jpg', NULL, 1, 1, 0, 0, 0, 0, 0, '2025-03-27 09:39:30', '2025-03-27 09:39:30', NULL),
(6, 'HOSPITAL MUNICIPAL DO CUBAL', 'Benguela', 'Cubal', NULL, NULL, -13.03760000, 14.25272600, 'Hospital', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'N/D', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 'Rosa Juca Sessa', '924419959', NULL, NULL, 1, '/storage/imagens/4QVjFh3yPE.jpg', NULL, 1, 1, 0, 0, 1, 0, 0, '2025-03-28 20:16:02', '2025-03-28 20:16:02', NULL),
(7, 'HOSPITAL NOSSA SENHORA DA PAZ', 'Benguela', 'Cubal', NULL, NULL, -13.02539800, 14.23064800, 'Hospital', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'N/D', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, 'Maria Rosalina Praia', NULL, NULL, NULL, 1, '/storage/imagens/dSgp6YGbsM.jpg', NULL, 1, 1, 0, 0, 0, 1, 0, '2025-03-28 20:38:41', '2025-03-28 20:38:41', NULL),
(8, 'POSTO DE SAUDE PASSAGEM', 'Benguela', 'Cubal', NULL, NULL, -13.03642400, 14.26026900, 'Posto de Saúde', 0, 0, 0, 0, 0, 1, 1, 0, 0, 'N/D', 0, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, '08-15H', 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 10, 0, 0, NULL, 'Melma Manuela T. Ch. Sapalo', '928903494', NULL, NULL, 1, '/storage/imagens/T3oknZ4Cc3.jpg', NULL, 0, 0, 0, 0, 0, 0, 0, '2025-03-28 21:15:37', '2025-03-28 21:15:37', NULL),
(9, 'Posto Médico Tchimbassi', 'Benguela', 'Cubal', NULL, NULL, -13.06115700, 14.22492200, 'Posto de Saúde', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'N/D', 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0, '8-15', 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 'N/D', 'Esperança Katumbo', '925427983', NULL, NULL, 1, '/storage/imagens/oEdoEEVYB1.jpg', NULL, 0, 0, 0, 0, 0, 0, 0, '2025-03-28 21:34:00', '2025-03-28 21:34:00', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `provincias`
--

CREATE TABLE `provincias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `paises_id` bigint(20) UNSIGNED NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `provincias`
--

INSERT INTO `provincias` (`id`, `nome`, `paises_id`, `estado`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Benguela', 1, 1, '2025-03-24 09:58:52', '2025-03-24 09:58:52', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sectores`
--

CREATE TABLE `sectores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servicoe_posto__posto_saudes`
--

CREATE TABLE `servicoe_posto__posto_saudes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `postos_saude_id` bigint(20) UNSIGNED NOT NULL,
  `servicos_posto_id` bigint(20) UNSIGNED NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `servicos_postos`
--

CREATE TABLE `servicos_postos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nome` varchar(255) NOT NULL COMMENT 'ex: palestras, orientacao individual, grupo de apoio, etc.',
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('0z1WqbxfecK224vKTVMPt56kGDJ1WDfcAfbv16U3', NULL, '105.172.234.36', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoieFFyUkM1dEFOZ0VUTEhPSk1IdXZOMmd6TFhtdUxYb1NjZHJVMzhINSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743872863),
('3x47aTdU4wq5ROkWvPjcoHGx199TZGm4eisSiuYb', NULL, '198.235.24.54', '', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoidW5naHFjZE5tb3J3cUJiMjUxTmdTNkV1SmI5ZTJXZTlCWEZEbGE5RiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743901920),
('7MdDe9b8SMLDvsvBxvGskabLvnq1Fok9wEPhwjB4', NULL, '35.92.210.78', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiMGg1cVlUS3h3RHU0emR1VEVlU2poMmdoamhOQnVKeDBybEdwaGJxciI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743870734),
('8RwZ7l5N3HSxTXqCN2E0YTdXeKHImjJUXt8ez2JV', NULL, '102.214.36.185', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUjJRSzJwMmNSemtlM1lFR01obTBBMjRHWG82cmY4RDZTbWhLcENqeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743923200),
('bjn1j1UWZV3rzV6yGtaofaf8K7enoOwMsNmtrYmT', NULL, '40.77.167.149', 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; bingbot/2.0; +http://www.bing.com/bingbot.htm) Chrome/116.0.1938.76 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiMTkwWTZ1Y252V2hwdVRtMG5mZ1hXcnVvN0JWVFI5bEM1N2JIVVJTVyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743874083),
('c8Wa17SkxGdClfMA5KrI8LpHxLXBv5upyJmk0CK7', NULL, '98.81.54.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiS0pNcFBLcVlreFp4a05lNmljSVRQTEdNQ0doZ2dLNUhtNndad0ZaZSI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNDoiaHR0cHM6Ly93d3cuY2hhbmNlYXBwLmFvIjt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjQ6Imh0dHBzOi8vd3d3LmNoYW5jZWFwcC5hbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1743959717),
('DtmUF4ierp2GxyeGOuB8REt1vXeHmyL2faGUoS85', 1, '105.168.81.19', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 Edg/135.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiTFp1RmFGaGI2Z3k1WGlsSmx0RkFSWExvY0JqWkRQTXBTUEFRc3NHMyI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNzoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vSW5pY2lvIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743976975),
('FaCGFAVZdPay2G6GpTOJMtZOZuANwUMx7eKqt3Vs', NULL, '24.199.120.153', 'Mozilla/5.0 (compatible)', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVUt4V1dZd3RWb2F0Y2RWOE0xTkNwcHlRY2IwYkdEYUR1Y1lQOTloZiI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743906495),
('jT1aAoul9XbG24ppgY0Giatqf3L5C6NyczeNPsos', NULL, '24.199.120.153', 'Mozilla/5.0 (compatible)', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVkRJdTh0eTVobG83OUxhUFI5Nld1MU1Ia3MxM2VaSWZKblIzbk9odyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743906500),
('OLbkfK3PFAzT79svsB0UP6cUDXZscB327COnQU5b', 1, '105.168.155.146', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiWm5ybjY0QlZUQk5zZEpHUlpKZ0hPYVlTYnhZUkZqV1lKbkFSSDE4cyI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjI2OiJodHRwczovL2NoYW5jZWFwcC5hby9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1743847498),
('PTMdtgHMKcncc4bhD0RaH3pnANhTDdEb7GJTRigF', NULL, '98.81.54.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaTJ6dURocHgwOVNFVndEZDJtbG9qNGFka0pkQ3RCenU2azV2TndCSyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyNDoiaHR0cHM6Ly93d3cuY2hhbmNlYXBwLmFvIjt9czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjQ6Imh0dHBzOi8vd3d3LmNoYW5jZWFwcC5hbyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1743959720),
('pz01ONIoPYiJe6Vn1EQmiUYTH6kogv82kI05hXuV', NULL, '3.88.181.15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNERZRms4MFlqWGxnR3JnSWt0OXFiNWhuOHFDY1A0RGVuOWdzOHhpRyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743959719),
('TG8NeHiJZaQzcL2FLmn3p7OzbKye9USIjZqIfznV', NULL, '93.123.109.63', '', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiblc0V2NGc3pDMERCWDRUN3B4Z2NZeGNYSTAwOXR4RlVvT21odnIybCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743922471),
('uWIxQxLeaEf3PCngQuOnuu1yZE9mpUMEUfvYpExa', NULL, '98.81.54.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRmpYNWtlUUZ0Q1BNMFpZdXZCanJYZXRNcjR4TUVsTlBzSGxPV0h4RiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmNoYW5jZWFwcC5hby9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1743959717),
('V5l1WvhNqDzv2HS3houRExKpSrOyYxAXz3wzPOwI', NULL, '98.81.54.4', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTVnNUpVRUpLck5HV0trblMwNGc5Y2NJTnVzbUVRSDFQRUswWFFEUiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHBzOi8vd3d3LmNoYW5jZWFwcC5hby9sb2dpbiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1743959721),
('VNcdbNybXXLN02hWEAnV8I46zpSPeECYL2oQIIoi', NULL, '54.209.60.63', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/600.1.25 (KHTML, like Gecko) Version/8.0 Safari/600.1.25', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicEJ5cGU2SkFPU3NzSER0bEpCNWE0RmtPeHZmdXgxMkd1eFZrUUh2OSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743936874),
('wdlgYRSTh4T79KTYIcdE2zw2Wo9VSz1oaQWV5zuo', NULL, '35.92.210.78', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRUhHMmZnQk1HUldObVhDU3JFUTBZdkhaR0oyUDgzd0NWVGJDMzBKNCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743870733),
('wxqqhYTQfOXD4DzXySyN1ycJXFHOFXogcP7BTyIg', NULL, '198.235.24.54', '', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiSDliTUhhNkZFcEY3R282MGJFVTZwR21HNzZJdXo1YkhZTHBzUkc4YyI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743901919),
('xeeHjW3ZVIz74Oj3QGsZUy88Bz0zgyx5YhLiU9R1', NULL, '37.29.152.3', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_1) AppleWebKit/601.2.4 (KHTML, like Gecko) Version/9.0.1 Safari/601.2.4 facebookexternalhit/1.1 Facebot Twitterbot/1.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiVFhsbWdjb2JyMzhEWWJKb0libERMbTc3TkRpQ0YxVlcycXI0M0ZleCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyNjoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8vbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743862772),
('XORd2GimvDes4aYVMRhmaSax34xUyFIV50GcIoDK', NULL, '64.23.233.179', '', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiNEJ2aElBN0M2RVZRSmdLWHdyMzV3UVVQVldITVFBcDExaWQzQVRseCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czoyMDoiaHR0cHM6Ly9jaGFuY2VhcHAuYW8iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1743865406),
('ZfMgkQabQ5oaPJphaFNpzz1lGa2NSRHatk6UrfxN', NULL, '3.88.181.15', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSjdJb2kxUXp0SGFsYWhBbTJadzNRdXFtRERRZGl0andTUWVYMEwwYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjY6Imh0dHBzOi8vY2hhbmNlYXBwLmFvL2xvZ2luIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1743959719);

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `controle_de_acesso_id` bigint(20) UNSIGNED NOT NULL,
  `level` enum('admin','professor','tecnico_saude','usuario_final') NOT NULL DEFAULT 'usuario_final',
  `estado` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'pode servir como apagado ou nao apagado, activo ou nao activo, vizivel ou nao vizivel',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `active_status` tinyint(1) NOT NULL DEFAULT 0,
  `avatar` varchar(255) NOT NULL DEFAULT 'avatar.png',
  `dark_mode` tinyint(1) NOT NULL DEFAULT 0,
  `messenger_color` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `controle_de_acesso_id`, `level`, `estado`, `remember_token`, `created_at`, `updated_at`, `deleted_at`, `active_status`, `avatar`, `dark_mode`, `messenger_color`) VALUES
(1, 'Admin User', 'admin@admin.com', '2025-03-24 09:58:52', '$2y$12$RaTe1wEP7Grzs2r7fkFepOGznVue.vTNBYi4Bsq71ExBCQEu7bziS', 1, 'usuario_final', 1, 'scy9DfUkl24kSWYWKDu6FeSW3ekeyRnQmuO86KLUXKcmaxQ2kp6doYVpnJ6K', '2025-03-24 09:58:52', '2025-03-25 09:03:03', NULL, 1, 'avatar.png', 0, NULL),
(2, 'Arminda Arminda', 'armindadongual@gmail.com', NULL, '$2y$12$CsOq8PAgQ56S2zx8H2fWqub2dw9wUsn.DE4XxHXIIzOv1I.Duo1le', 4, 'usuario_final', 1, NULL, '2025-03-24 13:51:50', '2025-03-24 13:51:50', NULL, 0, 'avatar.png', 0, NULL),
(3, 'Albertina Tadeu Tadeu', 'neidytadeu07@gmail.com', NULL, '$2y$12$t1KuZlUoLH3qMKmqzcgtpuFCvYczNkcWWdv60fs1MxLOQ19.TO2lu', 4, 'usuario_final', 1, NULL, '2025-03-24 13:52:32', '2025-03-24 13:52:32', NULL, 0, 'avatar.png', 0, NULL),
(4, 'Manuela Ngunza', 'manuelangunza18@gmail.com', NULL, '$2y$12$66mhwDZjSzpYaURqSN9xeO4v61f5ah77WijV9/wB21mTH7c9MYHeG', 4, 'usuario_final', 1, NULL, '2025-03-24 13:53:44', '2025-03-25 10:38:34', NULL, 0, 'avatar.png', 0, NULL),
(5, 'Alda Rocha', 'aldarocharocha021@gmail.com', NULL, '$2y$12$HOzze/LY5IzSI3.Spfa.fueOWb3/XGxamN3UpT1v6InIsezzqZL..', 4, 'usuario_final', 1, NULL, '2025-03-24 13:54:47', '2025-03-24 13:54:47', NULL, 0, 'avatar.png', 0, NULL),
(6, 'Gui Rodrigues', 'gui.ajsong@gmail.com', NULL, '$2y$12$9314Rr4bA19j4gXnYRHixuO76hLgKCsPxK77665OF4ZDeoSrXoCsK', 4, 'usuario_final', 1, NULL, '2025-03-24 13:56:12', '2025-03-24 13:56:12', NULL, 0, 'avatar.png', 0, NULL),
(7, 'Sabino Sakoka', 'sabinokapuputa2000@gmail.com', NULL, '$2y$12$2rPYIwYAjNsd9aFUNXyekum/0UUFRsauywZgNNnZ8UyLQUEiTIOua', 4, 'usuario_final', 1, 'EkBQ0SaV8yRzZXQZ5KAjjoj4cLAc24ioLDSbAWZ6KlTEFX1nOk8J1Loa1IuJ', '2025-03-24 13:56:58', '2025-03-25 09:09:26', NULL, 1, 'avatar.png', 0, NULL),
(8, 'Júlio Lofa Martinho', 'martinhokakumba@gmail.com', NULL, '$2y$12$kkbV0q8mEMmKnlXlhCVriOy9asnL6CkGuQ70Jznq7k42nZ.nUrFOG', 4, 'usuario_final', 1, 'r5ASWsQRBgjpxAXUFPt267vw8Ls9W8wbfnZs4VIG2v1dfZzhcQzfuVbN4pVH', '2025-03-24 13:57:39', '2025-03-25 09:08:40', NULL, 1, 'avatar.png', 0, NULL),
(9, 'Esperanza', 'esperanza.esteban@vhir.org', NULL, '$2y$12$NRZp.ZLvdjY5dc5VBkLH.ejVLkAMOh7dfLpkE6hbcO3LygKecYjFS', 3, 'usuario_final', 1, 'E77Oa9lukOcFBKBkcvl1ORQpNpctXBMbzVkVKBfUXe6eb6G8nnMRVAGllnRz', '2025-03-24 13:58:49', '2025-03-24 13:58:49', NULL, 0, 'avatar.png', 0, NULL),
(10, 'Inácio Nangol', 'inacionangolonangolo@gmail.com', NULL, '$2y$12$L4q.VLgeyLa3NGFGy7PuQOTJGzi.7.Idm0MOeFa/z7ajFIa6LiQ46', 4, 'usuario_final', 1, NULL, '2025-03-24 14:00:49', '2025-03-24 14:00:49', NULL, 0, 'avatar.png', 0, NULL),
(11, 'Rodrigues Boano Tomas', 'rodriguesboano@gmail.com', NULL, '$2y$12$xnh3k3ddjtF4/rXokjt8/eZJjvQIOginRxbGstpG6u41P3qaeeOJO', 4, 'usuario_final', 1, NULL, '2025-03-24 14:02:06', '2025-03-24 14:02:06', NULL, 0, 'avatar.png', 0, NULL),
(12, 'Francisca Zacarias', 'franciscazacariasadvoga@gmail.com', NULL, '$2y$12$fHwyNVP8gv9AyREgYbhZKuRFA8v7EVx1JnO6bfyowDX9CJ1fSjFxS', 4, 'usuario_final', 1, NULL, '2025-03-24 14:03:06', '2025-03-25 09:12:51', NULL, 0, 'avatar.png', 0, NULL),
(13, 'Benvinda do Rosário Baptista', 'benvindabaptista12@gmail.com', NULL, '$2y$12$dN7S8QtYeBtYtvGocxlVFuvGw38YoBI5WUuAZJLlrcNUVhB.52QQ2', 4, 'usuario_final', 1, NULL, '2025-03-24 14:03:56', '2025-03-24 14:03:56', NULL, 0, 'avatar.png', 0, NULL),
(14, 'Fernando Vaquero', 'fvaquero@universaldoctor.com', NULL, '$2y$12$sNXmiuQAbxh4Fvzd00JiKOik.cM6byxjs7XnNLr/uBLD4pZWl2UUe', 3, 'usuario_final', 1, NULL, '2025-03-25 08:08:16', '2025-03-25 08:08:16', NULL, 0, 'avatar.png', 0, NULL),
(15, 'Jordi serrano', 'jserranopons@universaldoctor.com', NULL, '$2y$12$tnUhW27eBwtjbMvoCfWOc.0DSLC.k.AAGUmoJ9pUoLNCnA2gDAmr.', 3, 'usuario_final', 1, NULL, '2025-03-25 08:08:54', '2025-03-25 08:08:54', NULL, 0, 'avatar.png', 0, NULL),
(16, 'Cristina Espinoza', 'cristina.espinoza.c@gmail.com', NULL, '$2y$12$Ib8v4n73keTvbgnOF1677eDjXZFvewOZ8rlHp9ro0zcS3oCCjQwvm', 3, 'usuario_final', 1, NULL, '2025-04-02 06:52:52', '2025-04-02 09:14:49', NULL, 0, 'avatar.png', 0, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `actividades`
--
ALTER TABLE `actividades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `actividades_servicoe_posto__posto_saude_id_foreign` (`servicoe_posto__posto_saude_id`),
  ADD KEY `actividades_palestrante_id_foreign` (`palestrante_id`);

--
-- Índices para tabela `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject` (`subject_type`,`subject_id`),
  ADD KEY `causer` (`causer_type`,`causer_id`),
  ADD KEY `activity_log_log_name_index` (`log_name`);

--
-- Índices para tabela `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bairros_municipios_id_foreign` (`municipios_id`);

--
-- Índices para tabela `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Índices para tabela `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Índices para tabela `ch_favorites`
--
ALTER TABLE `ch_favorites`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `ch_messages`
--
ALTER TABLE `ch_messages`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `controle_de_acessos`
--
ALTER TABLE `controle_de_acessos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `controle_de_acessos_nome_unique` (`nome`);

--
-- Índices para tabela `curricula`
--
ALTER TABLE `curricula`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `curricula_cadeira_unique` (`cadeira`);

--
-- Índices para tabela `curriculos_escolas`
--
ALTER TABLE `curriculos_escolas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `curriculos_escolas_escolas_id_foreign` (`escolas_id`),
  ADD KEY `curriculos_escolas_curriculum_id_foreign` (`curriculum_id`);

--
-- Índices para tabela `escolas`
--
ALTER TABLE `escolas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Índices para tabela `funcionalidades`
--
ALTER TABLE `funcionalidades`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Índices para tabela `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `logs_user_id_foreign` (`user_id`);

--
-- Índices para tabela `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_uuid_unique` (`uuid`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `media_order_column_index` (`order_column`);

--
-- Índices para tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mensagens_remetente_foreign` (`remetente`),
  ADD KEY `mensagens_destinatario_foreign` (`destinatario`);

--
-- Índices para tabela `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `municipios_provincias_id_foreign` (`provincias_id`);

--
-- Índices para tabela `niveis_acessos`
--
ALTER TABLE `niveis_acessos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `niveis_acessos_nome_unique` (`nome`);

--
-- Índices para tabela `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paises_nome_unique` (`nome`);

--
-- Índices para tabela `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Índices para tabela `permissoes`
--
ALTER TABLE `permissoes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissoes_niveis_acesso_id_foreign` (`niveis_acesso_id`),
  ADD KEY `permissoes_funcionalidades_id_foreign` (`funcionalidades_id`);

--
-- Índices para tabela `pessoas`
--
ALTER TABLE `pessoas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `postos_saudes`
--
ALTER TABLE `postos_saudes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provincias_paises_id_foreign` (`paises_id`);

--
-- Índices para tabela `sectores`
--
ALTER TABLE `sectores`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `servicoe_posto__posto_saudes`
--
ALTER TABLE `servicoe_posto__posto_saudes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `servicoe_posto__posto_saudes_postos_saude_id_foreign` (`postos_saude_id`),
  ADD KEY `servicoe_posto__posto_saudes_servicos_posto_id_foreign` (`servicos_posto_id`);

--
-- Índices para tabela `servicos_postos`
--
ALTER TABLE `servicos_postos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_controle_de_acesso_id_foreign` (`controle_de_acesso_id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `actividades`
--
ALTER TABLE `actividades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT de tabela `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `bairros`
--
ALTER TABLE `bairros`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `controle_de_acessos`
--
ALTER TABLE `controle_de_acessos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `curricula`
--
ALTER TABLE `curricula`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `curriculos_escolas`
--
ALTER TABLE `curriculos_escolas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `escolas`
--
ALTER TABLE `escolas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `funcionalidades`
--
ALTER TABLE `funcionalidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `logs`
--
ALTER TABLE `logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `media`
--
ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `mensagens`
--
ALTER TABLE `mensagens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `niveis_acessos`
--
ALTER TABLE `niveis_acessos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `paises`
--
ALTER TABLE `paises`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `permissoes`
--
ALTER TABLE `permissoes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pessoas`
--
ALTER TABLE `pessoas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `postos_saudes`
--
ALTER TABLE `postos_saudes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `provincias`
--
ALTER TABLE `provincias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `sectores`
--
ALTER TABLE `sectores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `servicoe_posto__posto_saudes`
--
ALTER TABLE `servicoe_posto__posto_saudes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `servicos_postos`
--
ALTER TABLE `servicos_postos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `actividades`
--
ALTER TABLE `actividades`
  ADD CONSTRAINT `actividades_palestrante_id_foreign` FOREIGN KEY (`palestrante_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `actividades_servicoe_posto__posto_saude_id_foreign` FOREIGN KEY (`servicoe_posto__posto_saude_id`) REFERENCES `servicoe_posto__posto_saudes` (`id`);

--
-- Limitadores para a tabela `bairros`
--
ALTER TABLE `bairros`
  ADD CONSTRAINT `bairros_municipios_id_foreign` FOREIGN KEY (`municipios_id`) REFERENCES `municipios` (`id`);

--
-- Limitadores para a tabela `curriculos_escolas`
--
ALTER TABLE `curriculos_escolas`
  ADD CONSTRAINT `curriculos_escolas_curriculum_id_foreign` FOREIGN KEY (`curriculum_id`) REFERENCES `curricula` (`id`),
  ADD CONSTRAINT `curriculos_escolas_escolas_id_foreign` FOREIGN KEY (`escolas_id`) REFERENCES `escolas` (`id`);

--
-- Limitadores para a tabela `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `mensagens`
--
ALTER TABLE `mensagens`
  ADD CONSTRAINT `mensagens_destinatario_foreign` FOREIGN KEY (`destinatario`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `mensagens_remetente_foreign` FOREIGN KEY (`remetente`) REFERENCES `users` (`id`);

--
-- Limitadores para a tabela `municipios`
--
ALTER TABLE `municipios`
  ADD CONSTRAINT `municipios_provincias_id_foreign` FOREIGN KEY (`provincias_id`) REFERENCES `provincias` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `permissoes`
--
ALTER TABLE `permissoes`
  ADD CONSTRAINT `permissoes_funcionalidades_id_foreign` FOREIGN KEY (`funcionalidades_id`) REFERENCES `funcionalidades` (`id`),
  ADD CONSTRAINT `permissoes_niveis_acesso_id_foreign` FOREIGN KEY (`niveis_acesso_id`) REFERENCES `niveis_acessos` (`id`);

--
-- Limitadores para a tabela `provincias`
--
ALTER TABLE `provincias`
  ADD CONSTRAINT `provincias_paises_id_foreign` FOREIGN KEY (`paises_id`) REFERENCES `paises` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `servicoe_posto__posto_saudes`
--
ALTER TABLE `servicoe_posto__posto_saudes`
  ADD CONSTRAINT `servicoe_posto__posto_saudes_postos_saude_id_foreign` FOREIGN KEY (`postos_saude_id`) REFERENCES `postos_saudes` (`id`),
  ADD CONSTRAINT `servicoe_posto__posto_saudes_servicos_posto_id_foreign` FOREIGN KEY (`servicos_posto_id`) REFERENCES `servicos_postos` (`id`);

--
-- Limitadores para a tabela `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_controle_de_acesso_id_foreign` FOREIGN KEY (`controle_de_acesso_id`) REFERENCES `controle_de_acessos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
